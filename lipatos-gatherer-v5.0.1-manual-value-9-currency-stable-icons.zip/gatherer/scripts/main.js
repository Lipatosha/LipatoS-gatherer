import { GathererSheet } from "./app/gathererSheet.js";
import { GathererActorConfig } from "./app/actorConfig.js";
import { registerSettings } from "./settings.js";
import { canBeHarvested } from "./helpers.js";
import { Socket } from "./lib/socket.js";
import { GathererMigration } from "./migration.js";
import GathererJournalPageData from "./GathererPageData.js";
import "../scss/module.scss";
import { SheetEmbed } from "./SheetEmbed.js";

export const MODULE_ID = "gatherer";
export const API = {};

Hooks.on("init", () => {

    customElements.define('gatherer-sheet-embed', SheetEmbed);

    SheetEmbed.setupHooks();

    Object.assign(CONFIG.JournalEntryPage.dataModels, {
        "gatherer.gatherer": GathererJournalPageData,
    });

    const module = game.modules.get(MODULE_ID);
    module.API = API;

    API.migration = new GathererMigration();

    registerSettings();

    globalThis.gatherer = GathererSheet;

    foundry.applications.apps.DocumentSheetConfig.registerSheet(JournalEntryPage, MODULE_ID, GathererSheet, {
        types: ["gatherer.gatherer"],
        label: "Gatherer Sheet",
    });

    game.keybindings.register(MODULE_ID, "harvestToken", {
        name: game.i18n.localize(`${MODULE_ID}.harvestToken`),
        editable: [{ key: "KeyG", modifiers: [foundry.helpers.interaction.KeyboardManager.MODIFIER_KEYS.SHIFT] }],
        restricted: false,
        onDown: () => { },
        onUp: () => {
            API.harvestToken();
        },
    });
});


Hooks.once("ready", async function () {

    if (game.user.isGM && game.settings.get("gatherer", "migrateOnStartup")) await API.migration.migrateAll();

    async function updateJournal(data) {
        const journal = await fromUuid(data.uuid);
        if (journal) {
            if (data.reset) {
                journal.unsetFlag(MODULE_ID, "data");
            } else {
                journal.setFlag(MODULE_ID, "data", data);
            }
        }
    }

    async function updateActor(data) {
        const actor = await fromUuid(data.uuid);
        if (actor) {
            const draws = actor.getFlag(MODULE_ID, "draws") ?? "";
            if (!Number.isNumeric(draws)) return;
            const drawsInt = parseInt(draws);
            if (drawsInt <= 0) return;
            const newDraws = drawsInt - 1;
            await actor.setFlag(MODULE_ID, "draws", newDraws);
        }
    }

    Socket.register("updateJournal", updateJournal);
    Socket.register("updateActor", updateActor);


    API.harvestToken = async function (token) {
        token = token ?? Array.from(game.user.targets)[0];
        const actor = token?.actor;
        if (!actor) return;
        const journal = actor.getFlag(MODULE_ID, "gatherSheet") ?? "";
        if (!journal) return ui.notifications.warn(game.i18n.localize(`${MODULE_ID}.error.noJournal`));
        const draws = actor.getFlag(MODULE_ID, "draws") ?? "";
        const hasDraws = Number.isNumeric(draws);
        const drawsInt = parseInt(draws);
        if (hasDraws && drawsInt <= 0) return ui.notifications.warn(game.i18n.localize(`${MODULE_ID}.error.noDraws`));
        const document = await fromUuid(journal);
        if (!document) return;
        if (!canBeHarvested(actor)) return ui.notifications.warn(game.i18n.localize(`${MODULE_ID}.error.cantHarvest`) + ` (${game.settings.get(MODULE_ID, "resourcePath")} > ${game.settings.get(MODULE_ID, "resourceValue")})`)
        document.render(false);
        await document.sheet.getGathererData();
        document.sheet._onGather(!hasDraws, actor);
    };

    API.gather = async function (pageUuid, actorUuid) {
        const actor = actorUuid ? await fromUuid(actorUuid) : null;
        const journal = await fromUuid(pageUuid);
        if (!journal) return;
        journal.render(false);
        await journal.sheet.getGathererData();
        journal.sheet._onGather(true, null, actor);
    };
});

Hooks.on("renderRollTableSheet", (app, html) => {
    if (!app.isEditMode || html.querySelector("th.quantity")) return;
    html.querySelector("th.weight").insertAdjacentHTML("beforebegin", `<th class="quantity flexrow">${game.i18n.localize(`${MODULE_ID}.quantity`)}</th>`);
    const results = app.document.results;
    const rows = Array.from(html.querySelectorAll("tbody tr"));
    rows.forEach(row => {
        const resultId = row.dataset.resultId;
        const result = results.get(resultId);
        const quantity = result.flags?.gatherer?.quantity ?? 1;
        const rowIndex = rows.indexOf(row);
        row.querySelector("td.weight").insertAdjacentHTML("beforebegin", `<td class="quantity flexrow">
            <input type="text" name="results.${rowIndex}.flags.gatherer.quantity" value="${quantity}">
        </td>`);
    });
});

Hooks.on("updateWorldTime", () => {
    GathererSheet._onUpdateWorldTime();
});

Hooks.on("getActorSheetHeaderButtons", (app, buttons) => {
    if (!app.actor.hasPlayerOwner && game.user.isGM && game.settings.get(MODULE_ID, "enableHarvesting")) {
        buttons.unshift({
            class: "gatherer",
            icon: "fas fa-leaf",
            label: "Gatherer",
            onclick: () => {
                new GathererActorConfig(app.actor).render({ force: true });
            },
        });
    }
});

Hooks.on("getHeaderControlsActorSheetV2", (app, buttons) => {
    if (!app.document.hasPlayerOwner && game.user.isGM && game.settings.get(MODULE_ID, "enableHarvesting")) {
        buttons.push({
            action: "gatherer",
            icon: "fas fa-leaf",
            label: "Gatherer",
            onClick: () => {
                new GathererActorConfig(app.document).render(true);
            },
        });
    }
})