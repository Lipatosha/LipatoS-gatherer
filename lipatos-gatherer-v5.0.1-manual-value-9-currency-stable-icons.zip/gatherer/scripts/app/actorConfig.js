import { MODULE_ID } from "../main.js";
import { HandlebarsApplication, mergeClone } from "../lib/utils.js";

export class GathererActorConfig extends HandlebarsApplication {
    constructor(document) {
        super();
        this.document = document;
    }

    static get DEFAULT_OPTIONS() {
        return mergeClone(super.DEFAULT_OPTIONS, {
            tag: "form",
            window: {
                contentClasses: ["standard-form"],
            },
            form: {
                handler: this.#onSubmit,
                closeOnSubmit: true,
            },
            position: {
                width: 400,
            },
        });
    }

    static get PARTS() {
        return {
            content: {
                template: `modules/${MODULE_ID}/templates/${this.APP_ID}.hbs`,
                classes: ["standard-form", "scrollable"],
            },
            footer: {
                template: "templates/generic/form-footer.hbs",
            }
        };
    }
    
    async _prepareContext(options) {
        const saveButton = {
            type: "submit",
            action: "submit",
            icon: "fas fa-check",
            label: "Save",
        };
        return { actor: this.document, buttons: [saveButton] };
    }

    static async #onSubmit() {
        const form = this.element;
        let formData = new foundry.applications.ux.FormDataExtended(form).object;
        formData = foundry.utils.expandObject(formData);
        return this.document.update(formData);
    }
}
