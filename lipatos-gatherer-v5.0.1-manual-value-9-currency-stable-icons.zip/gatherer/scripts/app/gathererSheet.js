import { Socket } from "../lib/socket.js";
import { MODULE_ID } from "../main.js";

export class GathererSheet extends foundry.applications.sheets.journal.JournalEntryPageProseMirrorSheet {
    constructor(...args) {
        super(...args);
        this.isV2 = true;
        this.onAddRollCondition = this._onAddRollCondition.bind(this);
        this.onRemoveRollCondition = this._onRemoveRollCondition.bind(this);
    }

    static CLEAN_ARRAYS = ["flags.gatherer.modifierList"];

    static DEFAULT_OPTIONS = {
        actions: {},
        classes: ["text"],
        includeTOC: true,
        position: {
            height: "auto",
            // width: "auto",
        }
    };

    /* -------------------------------------------- */

    /** @override */
    static EDIT_PARTS = {
        header: super.EDIT_PARTS.header,
        content: {
            classes: ["gatherer-config-text"],
            template: "templates/journal/pages/text/edit.hbs"
        },
        config: {
            classes: ["standard-form", "scrollable"],
            scrollable: [""],
            template: "modules/gatherer/templates/gatherer-sheet-config.hbs",
        },
    };

    /* -------------------------------------------- */

    /** @override */
    static VIEW_PARTS = {
        content: {
            root: true,
            template: "templates/journal/pages/text/view.hbs"
        },
        gathererContent: {
            template: "modules/gatherer/templates/gatherer-sheet.hbs",
        },
    };

    _configureRenderParts(options) {
        const parts = ( this.isView || options.forceView ) ? this.constructor.VIEW_PARTS : this.constructor.EDIT_PARTS;
        return foundry.utils.deepClone(parts);
    }

    async _prepareContentContext(context, options) {
        if ( this.isView || options.forceView ) context.text.enriched = await foundry.applications.ux.TextEditor.implementation.enrichHTML(context.text.content, {
            relativeTo: this.page,
            secrets: this.page.isOwner
        });
    }

    _setupEventListeners(html) {

        html.querySelector('.add-entry')?.addEventListener('click', this.onAddRollCondition);
        html.querySelectorAll('.remove-entry').forEach((button) => {
            button.addEventListener('click', this.onRemoveRollCondition);
        });

        const items = html.querySelectorAll(".gatherer-item");
        items.forEach((item) => {
            item.addEventListener("click", (e) => {
                const uuid = item.dataset.uuid;
                fromUuid(uuid).then((doc) => {
                    doc?.sheet?.render(true);
                });
                return;
            });
        });

        html.querySelector("#gatherer-reset")?.addEventListener("click", this._onReset.bind(this));
        html.querySelector("#gatherer-edit")?.addEventListener("click", () => this.document.sheet.render(true));
        html.querySelector("#gatherer-gather")?.addEventListener("click", (e) => this._onGather.call(this, true, null, null, e));
    }

    _onRender(context, options) {
        super._onRender(context, options);
        const html = this.element;
        this._setupEventListeners(html);
    }

    static CLEAN_ARRAYS = ["flags.gatherer.modifierList"];

    _prepareSubmitData(...args) {
        const submitData = super._prepareSubmitData(...args);
        for (const keyPath of this.constructor.CLEAN_ARRAYS) {
            const data = foundry.utils.getProperty(submitData, keyPath);
            if (data) foundry.utils.setProperty(submitData, keyPath, Object.values(data).sort((a, b) => b.DC - a.DC));
        }
        return submitData;
    }

    /** Append a blank object to the list and re-render */
    async _onAddRollCondition(event) {
        const currentList = this.document.getFlag("gatherer", "modifierList") ?? [];
        currentList.push({ modifier: "", DC: undefined });

        this.document.setFlag("gatherer", "modifierList", currentList);
    }

    /** Remove the entry at the clicked index */
    async _onRemoveRollCondition(event) {
        const index = Number(event.currentTarget.dataset.index);
        const currentList = this.document.getFlag("gatherer", "modifierList") ?? [];

        currentList.splice(index, 1);
        this.document.setFlag("gatherer", "modifierList", currentList);
    }

    getToolLabelFromKey(key) {
        if (key in CONFIG.DND5E.toolProficiencies) return CONFIG.DND5E.toolProficiencies[key];
        if (key in CONFIG.DND5E.vehicleTypes) return CONFIG.DND5E.vehicleTypes[key];
        if (key in CONFIG.DND5E.tools) {
            const item = CONFIG.DND5E.tools[key];
            if (typeof item == "string") {
                const name = fromUuidSync(item)?.name;
                if (name) return name;
                return item;
            }
            const name = fromUuidSync(item?.id)?.name;
            if (name) return name;
        }
        return key.charAt(0).toUpperCase() + key.slice(1);
    }

    getToolLabel(key, item) {
        if (typeof item == "string") {
            const name = fromUuidSync(item)?.name;
            if (name) return name;
            return item;
        }
        const name = fromUuidSync(item?.id)?.name;
        if (name) return name;
        return key.charAt(0).toUpperCase() + key.slice(1);
    }

    async _prepareContext(options) {
        const context = await super._prepareContext(options);
        const data = await this.getGathererData();
        const flags = this.document.flags.gatherer ?? {};
        let selectOptions = {};
        Array.from(game.tables).forEach((t) => (selectOptions[t.uuid] = t.name));
        flags.tables = selectOptions;
        const systemData = this.getSystemData();
        let tools;
        if (systemData) {
            foundry.utils.mergeObject(flags, systemData);
            flags.systemData = true;
            tools = {
                ...CONFIG.DND5E.toolProficiencies,
                ...CONFIG.DND5E.vehicleTypes,
                ...Object.entries(CONFIG.DND5E.tools).reduce((acc, [key, item]) => {
                    acc[key] = this.getToolLabel(key, item);
                    return acc;
                }, {}),
            };
        }

        return {
            ...context,
            ...data,
            ...flags,
            tools,
        };
    }

    getSystemData() {
        switch (game.system.id) {
            case "dnd5e":
                let abil = {};
                let skills = {};
                for (let [k, v] of Object.entries(game.dnd5e.config.skills)) {
                    skills[k] = v.label;
                }
                for (let [k, v] of Object.entries(game.dnd5e.config.abilities)) {
                    abil[k] = v.label;
                }
                const data = foundry.utils.mergeObject(foundry.utils.deepClone(abil), foundry.utils.deepClone(skills));
                return { systemSelect: data };
            default:
                return null;
        }
    }

    explodeTableResults(outerTable, { outerWeight = 1 } = {}) {
        let results = {};
        const table = outerTable.documentUuid ? fromUuidSync(outerTable.documentUuid) : outerTable;
        const tableItems = Array.from(table.results).filter(r => !r.drawn || table.replacement);
        if (!tableItems) return [];
        const totalWeight = tableItems.reduce((acc, r) => acc + r.weight, 0);
        for (const item of tableItems) {
            const uuid = item.documentUuid || item.name;
            const adjustedWeight = outerWeight * item.weight / totalWeight;
            if (!uuid.startsWith("RollTable")) {
                if (results[uuid]) results[uuid].adjustedWeight += adjustedWeight;
                else results[uuid] = { adjustedWeight, item };
                continue;
            }
            const innerTableItems = this.explodeTableResults(item, { outerWeight: adjustedWeight });
            for (const [uuid, innerItem] of Object.entries(innerTableItems)) {
                if (results[uuid]) results[uuid].adjustedWeight += innerItem.adjustedWeight;
                else results[uuid] = innerItem;
            }
        }
        results = Object.values(results);
        return results;
    }

    async getGathererData() {
        let data = foundry.utils.deepClone(this.document.flags.gatherer ?? {});
        if (data.table) data.table = await fromUuid(data.table);
        this._gathererData = data;
        const flag = foundry.utils.mergeObject(this.defaultGathererData, this.document.getFlag("gatherer", "data") || {});
        data = { ...data, isGM: game.user.isGM, pullsRemaining: this.MAX_DRAWS - flag.drawsUsed, resetTime: this.hasTime ? (flag.firstDrawTime == 0 ? game.i18n.localize("gatherer.sheet.waitingFirst") : this.parseMStoTime(this.TIMEMS - (game.time.worldTime * 1000 - flag.firstDrawTime * 1000))) : null, hasTime: this.hasTime, hasDraws: this.hasDraws, quantity: this.QUANTITY };
        if (!data.table) return {};
        const weightedResults = this.explodeTableResults(data.table);
        weightedResults.forEach(r => {
            r.percentWeight = (r.adjustedWeight * 100).toFixed(2);
            r.quantityMultiplier = r.item.getFlag(MODULE_ID, "quantity") ?? 1;
            r.minRoll = Number(r.item.range?.[0] ?? 0);
        });
        weightedResults.sort((a, b) => (a.minRoll - b.minRoll) || a.item.name.localeCompare(b.item.name, game.i18n.lang));
        data.weightedResults = weightedResults;
        this.weightedResults = weightedResults;
        data.size = 100 - weightedResults.length * 2;
        return data;
    }

    getResultUUID(result) {
        return result.documentUuid;
    }

    async _onGather(consumeDraw = true, harvestActor = null, gatheringActor = null, event = null) {
        if (
            !Array.from(game.users)
                .filter((u) => u.active)
                .some((u) => u.isGM)
        )
            return ui.notifications.error(game.i18n.localize("gatherer.sheet.err.noGM"));
        const actor = gatheringActor ?? canvas?.tokens?.controlled[0]?.actor ?? game.user.character;
        if (!actor) return ui.notifications.error(game.i18n.localize("gatherer.sheet.err.noActor"));
        if (this.REQUIRE?.length) {
            for (let req of this.REQUIRE) {
                const item = actor.items.getName(req);
                if (!item) return ui.notifications.error(game.i18n.localize("gatherer.sheet.err.noReq") + req);
            }
        }
        if (this.TOOLDC && this.TOOL) {
            const item = actor.system?.tools?.[this.TOOL];
            if (!item) return ui.notifications.error(game.i18n.localize("gatherer.sheet.err.noReq") + this.getToolLabelFromKey(this.TOOL));
        }
        const data = foundry.utils.mergeObject(this.defaultGathererData, this.document.getFlag("gatherer", "data") || {});
        if (this.hasDraws && data.drawsUsed >= this.MAX_DRAWS) {
            ui.notifications.error(game.i18n.localize("gatherer.sheet.err.noDraws"));
            return;
        }
        if (!data.firstDrawTime) {
            data.firstDrawTime = game.time.worldTime;
        }

        let rolledDC;
        if (this.EXPRESSION) {
            const res = await this.evaluateExpression(actor);
            if (res === false) Socket.updateJournal({ uuid: this.document.uuid, drawsUsed: this.hasDraws ? data.drawsUsed + 1 : 0, firstDrawTime: this.hasTime ? data.firstDrawTime : 0, hasTime: this.hasTime, hasDraws: this.hasDraws }, { users: Socket.USERS.FIRSTGM });
            if (res === false) return ui.notifications.warn(game.i18n.localize("gatherer.sheet.err.noExp"));
            if (Number.isFinite(res)) {
                rolledDC = res;
            }
        }

        if (consumeDraw) Socket.updateJournal({
            uuid: this.document.uuid, drawsUsed: this.hasDraws ? data.drawsUsed + 1 : 0, firstDrawTime: this.hasTime ? data.firstDrawTime : 0, hasTime: this.hasTime, hasDraws: this.hasDraws
        }, { users: Socket.USERS.FIRSTGM });


        if (harvestActor) Socket.updateActor({ uuid: harvestActor.uuid }, { users: Socket.USERS.FIRSTGM });

        if (this.SYSTEMABIL && this.supportedSystem && this.DC) {
            let result;
            if (game.dnd5e.config.abilities[this.SYSTEMABIL]) {
                result = await actor.rollAbilityCheck({ ability: this.SYSTEMABIL, event }, {});
            } else {
                result = await actor.rollSkill({ skill: this.SYSTEMABIL, event }, {});
            }
            result = result ? result[0] : { total: 0 };
            if (result.total < this.DC) {
                ui.notifications.error(game.i18n.localize("gatherer.sheet.err.noExp"));
                return;
            }
            rolledDC = result.total;
        }

        if (this.TOOLDC && this.TOOL && this.supportedSystem) {
            const item = actor.system?.tools?.[this.TOOL];
            const systemTool = actor.system.tools[this.TOOL];
            if (item || systemTool) {
                const roll = systemTool ? await actor.rollToolCheck({ tool: this.TOOL, event }, {}) : await item.rollToolCheck({ event });
                if (!roll) return;
                if (roll[0].total < this.TOOLDC) {
                    ui.notifications.error(game.i18n.localize("gatherer.sheet.err.noExp"));
                    return;
                }
                rolledDC = roll[0].total;
            }
        }

        // Identify applicable expression
        const expression = (rolledDC == undefined ? undefined : this.MODIFIERS.find(m => rolledDC >= m.DC)?.modifier) || "0";
        let processedExpression = Number.isFinite(parseInt(expression[0])) ? `+${expression}` : expression;
        if (!processedExpression.includes("$")) processedExpression = `$${processedExpression}`;        

        //Execute gathering
        let results = await this.runMinigame();
        if (!results) {
            if (rolledDC !== undefined) {
                // Use the skill/ability/expression result as the RollTable value.
                // Clamp values above the table range (e.g. Survival 24 on a 1d20 table)
                // to the highest configured result range.
                const maxTableValue = Math.max(...Array.from(this.table.results).map(r => r.range[1]));
                const tableValue = Math.max(1, Math.min(rolledDC, maxTableValue));
                results = this.table.getResultsForRoll(tableValue);
            } else {
                const tableResult = await this.table.draw({ displayChat: false });
                results = tableResult.results;
            }
        }
        if (!results) return ui.notifications.error(game.i18n.localize("gatherer.sheet.err.noItem"));

        let itemList = [];
        for (const result of results) {
            if (!this.table.replacement) await result.update({ drawn: true });
            const document = await fromUuid(result.documentUuid);
            const quantityFlag = result.getFlag(MODULE_ID, "quantity") ?? 1;
            const quantityRoll = await new Roll(processedExpression.replaceAll("$", `${this.QUANTITY}*${quantityFlag}`), actor).roll();
            let quantity = quantityRoll.total;
            // Do not add zero/negative quantity results to inventory or chat.
            if (quantity <= 0) continue;
            itemList.push({
                item: result.type === "text" ? result : document,
                quantity: quantity,
            });
        }

        // If all rolled quantities were 0 (for example 1d2-1), show a failure message
        // instead of an empty "Gathered" card.
        if (!itemList.length) {
            return ui.notifications.warn(game.i18n.localize("gatherer.sheet.err.noExp"));
        }

        const gatherData = {
            actor: actor,
            things: itemList,
        };

        Hooks.callAll("gathererGather", gatherData);

        const things = gatherData.things;
        const quantityPath = game.settings.get(MODULE_ID, "quantityPath");
        for (let thing of things) {
            if (!(thing.item instanceof CONFIG.Item.documentClass.implementation)) continue;
            const previewsItem = actor.items.getName(thing.item.name);
            if (previewsItem) {
                const currentQuantity = foundry.utils.getProperty(previewsItem.system, quantityPath);
                const updateData = { system: {} };
                foundry.utils.setProperty(updateData.system, quantityPath, currentQuantity + thing.quantity);
                await previewsItem.update(updateData);
            } else {
                const itemData = thing.item.toObject();
                foundry.utils.setProperty(itemData.system, quantityPath, thing.quantity);
                await actor.createEmbeddedDocuments("Item", [itemData]);
            }
        }
        this.toChat(things, actor);
    }

    async toChat(things, actor) {

        const isItem = things.every(thing => thing.item instanceof CONFIG.Item.documentClass.implementation);

        let content = `
        <strong>${actor.name} ${isItem ? game.i18n.localize("gatherer.gathered") : game.i18n.localize("gatherer.found")}:</strong>
        <div class="table-draw">
        <ul class="table-results">`;
        for (let thing of things) {
            content += isItem ?
            `<li class="table-result flexrow">
                <img class="result-image" src="${thing.item.img}">
                <div class="result-text">@UUID[${thing.item.uuid}]{${thing.item.name} X ${thing.quantity}}</div>
            </li>` :
            `<li class="table-result flexcol">
                <li class="table-result flexrow">
                <img class="result-image" src="${thing.item.img}">
                    <div class="result-text"><strong>${thing.item.name}</strong></div>
                </li>
                <div class="result-text">${thing.item.description}</div>
            </li>`;
        }
        content += `</ul>
        </div>`;

        ChatMessage.create(
            ChatMessage.applyRollMode(
                {
                    content: await foundry.applications.ux.TextEditor.implementation.enrichHTML(content),
                    speaker: { actor: actor.id },
                },
                game.settings.get("core", "rollMode"),
            ),
        );
    }

    async evaluateExpression(actor) {
        const AsyncFunction = async function () { }.constructor;
        const fn = new AsyncFunction("actor", $("<span />", { html: this.EXPRESSION }).text());
        try {
            return await fn(actor);
        } catch (e) {
            ui.notifications.error("There was an error in your macro syntax. See the console (F12) for details");
            console.error(e);
            return false;
        }
    }

    async runMinigame() {
        if (!this.MINIGAME) return false;
        const weightedResults = this.weightedResults;
        let minigameTime = this.MINIGAME;
        let currentItem = null;
        let minigameCompleted = false;
        async function wait(ms) {
            return new Promise((resolve) => {
                setTimeout(resolve, ms);
            });
        }
        return new Promise(async (resolve, reject) => {
            const dialog = new foundry.applications.api.DialogV2({
                window: { title: "gatherer.minigame.title" },
                content: `<div class="gatherer-minigame"><div class="gatherer-minigame-item" style="background-image: url('${weightedResults[0].item.img}')"></div></div>`,
                buttons: [
                    {
                        label: "gatherer.sheet.gather",
                        icon: "fas fa-leaf",
                        action: "confirm",
                        callback: function () {
                            minigameCompleted = true;
                            resolve([currentItem.item]);
                        },
                    },
                ],
                height: 400,
                render: (html) => {
                    html.closest(".window-app").style.width = "250px";
                },
            });
            await dialog.render({ force: true });
            while (!minigameCompleted) {
                if (!dialog.element) return resolve(false);
                const dhtml = dialog.element.querySelector(".gatherer-minigame");
                dhtml.innerHTML = "";
                const index = Math.floor(Math.random() * weightedResults.length);
                let randomItem = weightedResults[index];
                if (randomItem == currentItem) randomItem = weightedResults[(index + 1) % weightedResults.length];
                currentItem = randomItem;
                const html = document.createElement("div");
                html.className = "gatherer-minigame-item";
                html.style.backgroundImage = `url('${randomItem.item.img}')`;
                dhtml.prepend(html);
                await wait((parseFloat(randomItem.adjustedWeight)) * minigameTime);
                minigameTime *= 0.99;
            }
        });
    }

    async _onReset(force = false) {
        const data = foundry.utils.mergeObject(this.defaultGathererData, this.document.getFlag("gatherer", "data") || {});
        const timeDiff = game.time.worldTime - data.firstDrawTime;
        if (force || (this.hasTime && timeDiff * 1000 >= this.TIMEMS)) {
            Socket.updateJournal({ uuid: this.document.uuid, firstDrawTime: game.time.worldTime, drawsUsed: 0 }, { users: Socket.USERS.FIRSTGM });
        }
    }

    parseMStoTime(ms) {
        const time = new Date(ms);
        let hrs = time.getUTCHours();
        let mins = time.getUTCMinutes();
        let days = time.getUTCDate() - 1;
        return `${days}d ${hrs}h ${mins}m`;
    }

    get TOOL() {
        return this._gathererData?.toolCheck;
    }

    get TOOLDC() {
        return this._gathererData?.toolDC;
    }

    get SYSTEMABIL() {
        return this._gathererData?.systemAbil;
    }

    get DC() {
        return this._gathererData?.DC;
    }

    get TIME() {
        return parseFloat(this._gathererData?.time) ?? 0;
    }

    get TIMEMS() {
        const hours = this.TIME;
        return hours * 60 * 60 * 1000;
    }

    get MODIFIERS() {
        return this._gathererData?.modifierList ?? [];
    }

    get QUANTITY() {
        return this._gathererData?.quantity || "1";
    }

    get hasTime() {
        return this.TIME > 0;
    }

    get hasDraws() {
        return this.MAX_DRAWS > 0;
    }

    get MAX_DRAWS() {
        return parseInt(this._gathererData?.draws) ?? 0;
    }

    get MINIGAME() {
        return this._gathererData?.minigame || false;
    }

    get REQUIRE() {
        return (this._gathererData?.require ?? "")
            .split(",")
            .map((i) => i.trim())
            .filter((i) => i);
    }

    get EXPRESSION() {
        const macroExpression = game.macros.getName(this._gathererData?.expression)?.command;
        return macroExpression ?? this._gathererData?.expression ?? false;
    }

    get table() {
        return this._gathererData?.table ?? false;
    }

    get supportedSystem() {
        return this.getSystemData() != null;
    }

    get defaultGathererData() {
        return {
            drawsUsed: 0,
            firstDrawTime: 0,
        };
    }

    static _lastTime = 0;

    static _onUpdateWorldTime() {
        const now = game.time.worldTime;
        if (Math.abs(now - this._lastTime) > 60) {
            this._lastTime = now;
            console.log("Gatherer: Updating journals");
            Object.values(ui.windows)
                .filter((w) => w instanceof JournalSheet)
                .forEach((j) => {
                    if (j.element.find(".gatherer-container").length) j.render(true);
                });
        }
    }
}
