const { HTMLField, SchemaField, SetField, StringField } = foundry.data.fields;

/**
 * @import { GathererJournalSystemPageData } from "./_types.mjs";
 */

/**
 * Data definition for Gatherer Summary journal entry pages.
 * @extends {foundry.abstract.TypeDataModel<GathererJournalSystemPageData>}
 * @mixes GathererJournalSystemPageData
 */
export default class GathererJournalPageData extends foundry.abstract.TypeDataModel {

  async toEmbed(config, options={}) {
    const page = this.parent;
    const sheetEmbed = document.createElement("gatherer-sheet-embed");
    sheetEmbed.setAttribute("uuid", page.uuid);
    return sheetEmbed;
  }

  /** @inheritDoc */
  static LOCALIZATION_PREFIXES = ["gatherer"];

  /* -------------------------------------------- */

  /** @inheritDoc */
  static defineSchema() {
    const fields = foundry.data.fields;
    return {
      text: new fields.SchemaField({
        content: new fields.HTMLField({required: false, blank: true}),
        format: new fields.NumberField({
          required: true,
          initial: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML
        })
      })
    };
  }
}
