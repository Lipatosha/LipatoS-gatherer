
export class GathererMigration {
    constructor() { }

    async migrateAll() {
        ui.notifications.warn("Gatherer - Migrating all journal pages, do not refresh the page!");
        await this.migrateJournals();
        await this.migrateCompendiums();
        ui.notifications.notify(`Gatherer - Migration Complete.`);
        await game.settings.set("gatherer", "migrateOnStartup", false);
    }

    async antiMigrateAll() {
        ui.notifications.warn("Gatherer - Reverting all journal pages, do not refresh the page!");
        await this.antiMigrateJournals();
        await this.migrateCompendiums({ reverse: true });
        ui.notifications.notify(`Gatherer - Reverse migration Complete.`);
    }

    async antiMigrateJournals(journals = game.journal.contents) {
        if (!journals.length) return;

        let migratedJournalPages = 0;
        const tools = CONFIG.DND5E?.tools ?? {};
        const toolIdsToNames = Object.entries(tools).reduce((acc, t) => {
            const item = fromUuidSync(t[1].id)
            acc[t[0]] = item.name;
            return acc;
        }, {});

        const otherTools = {
            ...(CONFIG.DND5E?.toolProficiencies ?? {}),
            ...(CONFIG.DND5E?.vehicleTypes ?? {})
        }
        for (const key in otherTools) {
            toolIdsToNames[key] = otherTools[key];
        }

        for (const journal of journals) {
            const pages = Array.from(journal.pages);
            for (const page of pages) {

                // Migrate Page type (from gatherer.gatherer to text)
                if (page.type !== "gatherer.gatherer") continue;
                await page.setFlag("core", "sheetClass", "gatherer.GathererSheet");
                page.update({type: "text", "==system": null})
                migratedJournalPages++;

                // Migrate Tools (old version used name instead of id)
                if (!toolIdsToNames) continue;
                const toolFlag = await page.getFlag("gatherer", "toolCheck");
                if (!toolFlag) continue;
                const toolKey = toolIdsToNames[toolFlag];
                if (!toolKey) continue;
                await page.setFlag("gatherer", "toolCheck", toolKey);
            }
        }

        if (migratedJournalPages > 0) {
            ui.notifications.notify(`Gatherer - Migrated ${migratedJournalPages} journal pages.`);
            console.log(`Gatherer - Migrated ${migratedJournalPages} journal pages.`);
        } else {
            ui.notifications.notify(`Gatherer - No journal pages to migrate.`);
            console.log(`Gatherer - No journal pages to migrate.`);
        }
    }

    async migrateCompendiums({ reverse = false } = {}) {
        let migratedJournalPages = 0;
        const compendiums = Array.from(game.packs).filter((p) => p.documentName === "JournalEntry");
        for (const compendium of compendiums) {
            if(compendium.locked){
                console.warn(`Gatherer - Compendium ${compendium.collection} is locked, skipping migration.`);
                continue;
            }
            const journals = await compendium.getDocuments();
            if (reverse) this.antiMigrateJournals(journals);
            else this.migrateJournals(journals);
        }
        if (migratedJournalPages > 0) {
            ui.notifications.notify(`Gatherer - Migrated ${migratedJournalPages} journal pages in compendiums.`);
            console.log(`Gatherer - Migrated ${migratedJournalPages} journal pages in compendiums.`);
        } else {
            ui.notifications.notify(`Gatherer - No journal pages in compendiums to migrate.`);
            console.log(`Gatherer - No journal pages in compendiums to migrate.`);
        }
    }

    async migrateJournals(journals = game.journal.contents) {
        if (!journals.length) return;

        let migratedJournalPages = 0;
        const tools = CONFIG.DND5E?.tools ?? {};
        const toolNamesToIds = Object.entries(tools).reduce((acc, t) => {
            const name = fromUuidSync(t[1].id)?.name;
            if (!name) return acc;
            acc[name] = t[0];
            return acc;
        }, {});

        const otherTools = {
            ...(CONFIG.DND5E?.toolProficiencies ?? {}),
            ...(CONFIG.DND5E?.vehicleTypes ?? {})
        }
        for (const key in otherTools) {
            toolNamesToIds[otherTools[key]] = key;
        }

        for (const journal of journals) {
            const pages = Array.from(journal.pages);
            for (const page of pages) {

                // Migrate Page type (from text to gatherer.gatherer)
                const sheetClass = await page.getFlag("core", "sheetClass");
                if (sheetClass !== "gatherer.GathererSheet" || page.type !== "text") continue;
                await page.unsetFlag("core", "sheetClass");
                page.update({type: "gatherer.gatherer", "==system": null})
                migratedJournalPages++;

                // Migrate Tools (old version used name instead of id)
                if (!toolNamesToIds) continue;
                const toolFlag = await page.getFlag("gatherer", "toolCheck");
                if (!toolFlag) continue;
                const toolKey = toolNamesToIds[toolFlag];
                if (!toolKey) continue;
                await page.setFlag("gatherer", "toolCheck", toolKey);
            }
        }

        if (migratedJournalPages > 0) {
            ui.notifications.notify(`Gatherer - Migrated ${migratedJournalPages} journal pages.`);
            console.log(`Gatherer - Migrated ${migratedJournalPages} journal pages.`);
        } else {
            ui.notifications.notify(`Gatherer - No journal pages to migrate.`);
            console.log(`Gatherer - No journal pages to migrate.`);
        }
    }

    showManualMigrationDialog() {
        new foundry.applications.api.DialogV2({
            window: { title: "Gatherer - Migration" },
            content: `<p>Use this dialog to migrate your journal pages to the new structure. This is required for Gatherer to function properly.</p>
            <p><b>WARNING:</b> This will modify your journal data. Please back up your world before proceeding.</p>`,
            buttons: [
                {
                    label: "Migrate Local Journals",
                    action: "local",
                    callback: () => this.migrateJournals(),
                },
                {
                    label: "Migrate Journals in Compendiums",
                    action: "compendiums",
                    callback: () => this.migrateCompendiums(),
                },
                {
                    label: "Migrate All Journals",
                    action: "all",
                    callback: () => this.migrateAll(),
                }
            ],
        }).render({ force: true });
    }
}